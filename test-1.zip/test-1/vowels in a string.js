//2. Return the number of vowels in a string

//soluction here
function returnCount(str) {
    let result = {
      Alpha: 0,
      Digit: 0,
      Special: 0,
      Vowels: 0,
      Consonants: 0,
    };
  
    const vowels = "aeiouAEIOU";
  
    for (let char of str) {
      if (/[a-zA-Z]/.test(char)) {
        // It's a letter
        result.Alpha++;
        if (vowels.includes(char)) {
          result.Vowels++;
        } else {
          result.Consonants++;
        }
      } else if (/[0-9]/.test(char)) {
        // It's a digit
        result.Digit++;
      } else {
        // It's a special character
        result.Special++;
      }
    }
  
    return result;
  }
  
  let str = "A1b2@C3d#E4f5*G";
  console.log(returnCount(str));

  //-----output------
 // [ Alpha: 7, Digit: 5, Special: 3, Vowels: 2, Consonants: 5 ]
  