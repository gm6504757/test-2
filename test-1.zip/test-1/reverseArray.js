//1. Create a function that reverses an array
   function reverseArray(){
// write your solution here
// it should returns an reverse of an array
   }
   let arr = [2,1,4,2,5,3,5,4,35,63,6,6]
   console.log(reverseArray(arr)) 

//soluction here
function reverseArray(arr) {
    // Use the built-in reverse() method
    return arr.slice().reverse();
  }
  
  let arr = [2, 1, 4, 2, 5, 3, 5, 4, 35, 63, 6, 6];
  console.log(reverseArray(arr));
  
  // -----output-----
 // [ 6, 6, 63, 35, 4, 5, 3,  5,  2, 4, 1, 2 ]